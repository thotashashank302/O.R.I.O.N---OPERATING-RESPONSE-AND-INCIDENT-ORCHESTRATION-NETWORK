# Local setup

Use Node.js 22+. Run npm ci, restore your private .env (or configure .env.example), then run npm run local. Open http://localhost:3000.

The launcher starts both the app and recurring background checks, 10 seconds after each completed tick. Keep the terminal open and computer awake. Ctrl+C stops both. Vercel cron is not used. Your configured online database, AI and email services are still required. Jobs can update records and send queued emails. See README.md for full local instructions.

Dependencies and caches are excluded from this ZIP and occupy disk space again after installation. Plans are in docs/final-handoff. Private credentials are excluded.
