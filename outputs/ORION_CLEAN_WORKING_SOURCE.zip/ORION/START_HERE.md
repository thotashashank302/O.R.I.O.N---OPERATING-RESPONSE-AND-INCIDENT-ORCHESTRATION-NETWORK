# Run ORION locally

Node.js 22+. Run npm ci, restore your private .env configuration, then npm run build and npm run local:start. Open http://localhost:3000.

Keep the terminal running and computer awake for background processing. For editing, use npm run local instead. Supabase, AI and email remain online services. See README.md for recovery-email setup and REPAIRS.md for verification.
