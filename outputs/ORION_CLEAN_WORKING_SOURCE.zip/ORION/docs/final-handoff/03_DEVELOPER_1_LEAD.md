# Developer 1 — Shashank / Lead, AI and Integration
Read 01_MASTER_PLAN.md, 02_TECHNICAL_CONTRACTS.md and 08_VERIFICATION_DEMO_SUBMISSION.md first.
Ownership: shared contracts, migration integration, authorization policy helpers, Commander/common agent runner, durable jobs, integration, deployment and README. D2 drafts identity SQL/policies; D3 owns Triage, D4 Verification, D5 Specialist. D1 reviews their modules rather than implementing all four alone.

## Working protocol
Execute only one numbered task at a time. State files, assumptions and acceptance test; implement, verify and wait for developer approval. Do not silently change contracts after handoff. Ask for a UI reference before any lead-owned UI. Never implement before the organizer-approved window.
Dependency gate: publish shared types, endpoint envelopes and migration order in the first 30 minutes. Keep agents small; no separate agent servers.

## Part A — Foundation (0–2 hours)
### A1. Establish the integration baseline
Inspect the checkout first. Create the agreed Next.js/TypeScript structure only if absent. Pin compatible dependencies and Node runtime; establish typecheck, lint, test, build and E2E scripts. Publish ownership from the technical contract and environment-variable placeholders, never actual secrets.
Accept: clean baseline builds and deploys; all five developers know their paths and branches.
Verify: install from lockfile, typecheck and production build. Record any missing credentials as blockers.

### A2. Establish data and authorization contracts
Create migrations for the tables and enums in the technical contract, indexes, tenant-scoped foreign keys, explicit grants and RLS. Build reusable fresh-membership and role checks. Incorporate Developer 2's role/roster requirements; expose transactional service functions for other developers.
Accept: another college cannot read or mutate a case; inactive membership cannot use an old session; users cannot grant themselves roles.
Verify: two-tenant integration tests with ordinary user tokens, not only privileged server credentials.
Handoff: Developers 2–4 can now build against stable services. Lead alone applies shared migrations.

### A3. Prove Featherless integration
Use the exact provider configuration in technical contracts; confirm account access and latency using a real request. Validate model JSON with schemas; retry invalid output within the stated bounds. Add prompt-injection boundaries and structured run records.
Accept: a real incident text produces validated triage, with provider/model/time recorded; failures are visible rather than substituted with fake success.
Verify: one live request plus fixture tests for malformed output, timeout and hostile complaint text. Never log full confidential prompts publicly.

## Part B — Autonomous execution (2–5 hours)
### B1. Implement Commander and integrate the four-agent loop
Triage classifies and requests missing information; Commander creates a versioned plan; domain Specialist proposes bounded task actions; Verification checks required evidence and human decisions. One model can serve all four logical agents.
Implement approved tool schemas, dependency validation and concise decision summaries—not private chain-of-thought. Use current database facts for staff eligibility.
Accept: new reports create executable tasks, not merely prose or an email draft.
Verify: missing room leads to clarification; urgent risk bypasses voting; an invalid dependency cycle or unauthorized tool action is rejected.

### B2. Implement durable monitoring and action execution
Persist jobs and outbox entries; claim with leases and deduplication. Run short steps via the authenticated automation endpoint and configured scheduler. Use incident versions/locks and transactional assignment checks.
Integrate D4 assignment services and D5 email services. Urgent human alerts must not wait behind an LLM request. Configure retries, dead jobs and manual escalation.
Accept: an unacknowledged case progresses to reminder/escalation even with all browsers closed.
Verify: concurrent workers do not double-assign or double-send; interrupted leases recover; bad automation credentials fail.

### B3. Implement actual replanning
Consume rejected verification, unavailable staff, blocked tasks and acknowledgement deadlines. Reload facts, create a changed plan version and preserve history. Require approval for protected actions tied to that exact action/version.
Accept: failure changes assignee, task, dependency or escalation route; re-sending the identical email is not presented as replanning.
Verify: stale approvals and stale assignment updates fail; maximum attempts lead to accountable human escalation.

## Part C — Integration and delivery (5–7.5 hours; release thereafter)
### C1. Integrate the complete vertical slice
Connect D3 report/confirmation, D4 execution/evidence, D5 email/timeline and D2 eligibility. Review public versus private projections and all server authorization.
Accept: report → real AI plan → eligible staff → real email → acknowledgement → evidence → human verification → resolve OR changed replan works.
Verify: the verification checklist's P0 cases; resolve integration bugs before optional features.

### C2. Own release and README
At feature freeze, run checks and deploy the actual integrated commit. Author root README using the outline in 08; explicitly distinguish implemented, simulated and deferred features. Include Featherless architecture, setup, limitations, demo and deployment links.
Accept: a fresh checkout can follow setup, secrets are absent, public pages contain no private complaints.
Verify: lockfile install, build, deployed smoke test, public repository visibility and working video link.
Do not create a public repository or publish user data without the team's approval.

### C3. Lead submission readiness
Collect test results from every owner. Confirm official deadline/form; retain time for upload failures. Coordinate the three-minute demo with D5 and review the final submission receipt.
Accept: required artifacts are reachable and match the demonstrated build.
If behind: enforce master scope cuts. Never cut real AI, authorization, the action/replan loop or honest reporting to keep 3D polish.

## Handoffs and stop conditions
- Hour 0.5: contracts and ownership; hour 2: identity/model/email/deployment smoke results.
- Hour 5: end-to-end first assignment; hour 7.5: freeze.
- Missing scheduler, model access or email capability is a lead blocker, not something to hide behind mock data.
- Optional extra build time exists only if organizers confirm it; use it for robustness before more features.

## Revision 2 — integrate into existing parts
Read 09 and 10 before execution; do not treat these as extra work after release.
- A1: publish common agent input/output signatures, assign module paths, and establish separate checkouts plus per-developer progress files.
- A2: review/apply D2's identity migration draft; incorporate category configuration, CR seats, verification deadlines and lifecycle fields from 09.
- B1: implement Commander/common tool runner; integrate D3 Triage, D4 Verification, D5 Specialist, each with module tests.
- B2: process ready steps immediately within bounded hosting budget; scheduler recovers work. Measure live latency rather than promising instantaneous completion.
- B3: implement duplicate/lifecycle policy checks and safe completed-task carry-forward. Do not rerun completed unchanged work.
- C1/C2: require CORE tests and document real versus deferred features. Transport/clubs/feedback remain explicit P1; basics of onboarding cannot be cut.
