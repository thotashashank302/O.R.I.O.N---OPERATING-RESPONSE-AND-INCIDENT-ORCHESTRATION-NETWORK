# Developer 4 — Staff, HOD, Availability and Work Verification
Read the master, technical contracts and verification file. Own operations, availability, evidence services/screens and HOD action screens. D1 enforces the shared policy and orchestrates AI.

## Working protocol
One task at a time: identify files, implement, verify, pause for approval. Ask for staff/HOD layout templates before UI work. Request contract/migration changes from D1; reuse D2 identity helpers.

## Part A — Staff queue and availability (0–2 hours)
### A1. Staff work queue
Show only authorized assignments, task dependencies, location, due time and next action. Never expose private cases broadly to a department.
Accept: cleaners, electricians, security and other approved staff see their permitted work.
Verify: another department/college/user cannot fetch or mutate the assignment.

### A2. Staff self-availability control
Build Available / Busy / Off duty control, separate from admin membership Active / Inactive. Persist status, timestamp and audit event; optimistic UI must roll back on failure.
Accept: inactive or Off-duty users cannot receive new ordinary assignments; Busy does not mean inactive.
Verify: refresh persistence, unauthorized other-staff updates and failed network feedback.
An urgent Busy assignment requires the supervisor approval policy; never silently ignore eligibility.

### A3. Existing-work handling
When staff changes availability, show existing tasks and explicit continue-current-work or request-handover behavior allowed by policy. Keep an accountable owner until replacement accepts; Off duty is not permission to abandon work.
Accept: a handover creates an event for D1's replan loop, not an ownerless task.
Verify: simultaneous assignment and availability change is transactionally safe.

## Part B — Execution, evidence and approvals (2–5 hours)
### B1. Assignment actions
Implement acknowledge/start/block and handover transitions using expected versions and authorization. Expose one shared acknowledge service for D5's authenticated email confirmation POST.
Accept: email and dashboard acknowledge the same assignment exactly once; released/stale offers cannot be accepted.
Verify: repeated clicks, stale version, wrong staff and dependency not yet satisfied.

### B2. Staff evidence and submission
Collect repair notes, performed tests and optional private photos; use D3's upload service. Provide Submit for verification, never an unrestricted Resolve button.
Accept: internal issues require functional test information; blocked work records a reason and triggers orchestration.
Verify: missing evidence, wrong assignee and invalid state transition.

### B3. HOD oversight and protected actions
Provide scoped queue, deadline/escalation view, approval/rejection and authorized override. Approval is tied to a particular action and plan version with an audit trail.
Accept: a new plan invalidates an old approval; high-risk physical/security actions remain human controlled.
Verify: self-approval conflicts, out-of-scope HOD and stale approval.
Do not offer AI autonomous access to electrical controls or unlocking infrastructure.

## Part C — Verification and recovery (5–7.5 hours)
### C1. Human verification routing
Coordinate D3's reporter confirmation with designated HOD/lab verifier where required. Show pending verification and rejection feedback.
Accept: incident resolves only when required tasks and verification conditions pass; unresolved tasks are not hidden by one successful repair.
Verify: unauthorized closure, unresolved dependency and failed functional test.

### C2. Recovery demonstration
Exercise no acknowledgement, staff Off duty, handover and rejected verification against D1's worker. Render the changed plan and current responsible person.
Accept: the new assignment is eligible and the previous work history remains visible.
Verify: no duplicate active assignment, no dropped ownership and bounded escalation.

### C3. Operations test handoff
Give D1 automated transition/availability test results and known limits. Give D5 the staff portion of the demo.
Scope cut: postpone charts and elaborate department dashboards before availability, evidence or functional verification.

## Revision 2 — integrate into existing parts
Read 09 and 10 before execution.
- A1: own src/server/agents/verification.ts using D1's provider/types; build structured evidence checks and fixture tests. AI verdict alone cannot close physical/sensitive work.
- B2: use category-specific functional verifier rules; record evidence versions and stable task identity.
- B3: handle supervisor cancellation/duplicate reconciliation requests and absent-verifier escalation; keep accountability.
- C1/C2: coordinate revoked-verifier replacement, safe reopened cases and carry-forward of unchanged verified tasks. Expose the changed plan without losing active assignments.
- C3: run CORE-04/05 and provide module/live verification results to D1.

