# Final execution decisions — required companion to master
Revision 2, 4 September 2026. These decisions close the review gaps. They specify intended behavior, not implemented results. New defaults below are planning choices that the team can explicitly amend before implementation.

## 1. Complete core and explicit deferrals
P0: basic principal college creation/approval, department/room creation, manual roster rows, actual role grants, two CR slots, context switching, routine reports/votes, private exceptions, real four-agent workflow, staff states, communications, evidence/verification, recovery, duplicate linking and safe lifecycle actions.
P1: post-resolution feedback, transport/club screens, bulk import, rich assets/analytics and additional specialist configurations.
P2: visual campus map and approved 3D intro. Include the user's hostel/day-scholar distinction as an optional roster profile field; hostel-specific dashboards and bus integrations are not P0.
The full product vision is retained, but do not claim every P1/P2 feature fits the short window.

## 2. Category, handler and verifier mapping
| Category | Responsible group | Functional verifier |
| --- | --- | --- |
| IT/network/Wi-Fi/system issue | Configured IT support, not automatically electrical | Assigned lab owner or authorized reporting CR |
| Electrical/fan/AC | Qualified electrical/facilities team | Authorized CR/lab owner after staff safety clearance |
| Cleaning/sanitation | Cleaning team | Reporting CR or location owner |
| Facilities/furniture/plumbing | Configured maintenance team | Reporting CR/location owner |
| Door/key/access issue | Security with access authorization | Authorized requester/location owner |
| Transport | Verified route's transport admin | Authorized reporting rider or transport supervisor |
| Club operations | Authorized club coordinator/president workflow | Designated non-conflicted coordinator |
| Emergency/safety | Designated human emergency contact/supervisor immediately | Authorized human incident lead |
| Personal/CR misconduct | Explicit non-conflicted confidential recipient | Human case handler only |
| Unknown | Scoped operations supervisor | Supervisor selects appropriate verifier |

D2 supplies configured group IDs/contacts; D3 exposes categories; D1 policy sets safety floors; D5 Specialist uses this mapping; D4 enforces verification and approval. Missing responsible group => escalate to configured supervisor, never invent a department or send arbitrary mail.
A category is separate from severity and privacy. Personal complaints are confidential by default. Emergency notifications never depend on vote count or completion of model inference.
Staff membership/role approval remains with Principal or an explicitly authorized admin/supervisor; no automatic supervisory authority for ordinary staff.

## 3. Two CRs and multiple roles
D2: support two concurrently occupied CR seats per section/term. Use seat numbers, not a mandatory gender field; the college can appoint its chosen representatives. Unique active seat constraints prevent accidental third appointment.
HOD can revoke/replace within scope. Record grant/revocation actor, reason and time. Historical reports retain authorship; pending verification reassigns to remaining CR or HOD if the old verifier loses authority.
D2 owns context-switch state; D5 renders the shared selector. Switching context changes the scoped workspace, never creates a role. Server checks the selected institution and actual grant every request.
Test: revoke CR while their session is open, appoint replacement, verify old CR cannot act and the case is not stranded.

## 4. Duplicate policy — simple and safe
D3 owns linking API/UI; D1 validates transitions.
AI suggests same-tenant, same-scope routine duplicate candidates. A scoped HOD/admin explicitly confirms or rejects a link. Do not auto-merge ambiguous reports.
Keep both incident IDs, descriptions, reporters and history. Set parent_duplicate_id to one canonical incident; reject cycles and cross-privacy/tenant links. Linked child uses canonical work status and cannot launch a second active work plan.
Only link automatically safe-to-transition records with no active assignment; if either has active work, require supervisor reconciliation first. Block simple linking rather than silently canceling active work.
Votes remain on original records; priority counts distinct eligible voter IDs across the linked group, never the sum of counts. Notify both reporters through their permitted projections.
Confidential cases are excluded from duplicate search/linking.
Test: repeat voter across two linked reports counts once; unauthorized linking denied; active-work linking blocked.

## 5. Lifecycle rules
D1 implements transitions; D3 owns reporter actions; D4 owns supervisor decisions.
- Cancellation: routine reporter may cancel their own case only before assignment and only if no linked reports depend on it. Otherwise request supervisor cancellation with reason. Confidential/safety records cannot be self-deleted or casually canceled.
- Canceling accepted work requires supervisor disposition; retain audit, cancel only unstarted pending tasks/jobs, explicitly release assignments. Never delete history.
- Reopening: authorized reporter/verifier may reopen the same routine issue within 24 hours of resolution with a reason; later recurrence creates a new linked report. This is a demo product default, not a legal retention rule.
- Reopening increments version, clears current closure, queues Commander and preserves old evidence/verification.
- Missing verifier: reminder after 10 minutes, HOD/designated alternate escalation after 20 minutes; remains pending verification. No timeout auto-resolution.
- No eligible staff: accountable supervisor escalation, not repeated attempts to assign Off-duty people.
- Replan carry-forward: maintain stable logical task keys. Carry completed verification only if goal, location, evidence requirement and evidence version are unchanged; otherwise require new checks. Preserve references to source plan/task. Reconcile active assignments before replacing tasks. Never rerun verified physical work merely because plan version changed.
- Cancel/resolved/replanned cases invalidate stale jobs and action links by version/status checks.

## 6. Post-resolution feedback (P1)
D3: reporter may submit one 1–5 rating and optional comment per resolution version; allow an update. Feedback is distinct from functional confirmation and cannot silently reopen or close a case. Offer an explicit permitted Reopen action for continuing faults.
Restrict individual feedback to reporter and authorized supervisor; only non-sensitive aggregate metrics may be displayed broadly. No automated disciplinary judgments.
D1 supplies schema migration; test uniqueness, scope and no state mutation.

## 7. Additional contracts to publish before parallel work
All mutations use current membership, scope checks, version checks and audited transitions.
| Contract | Owner |
| --- | --- |
| POST /api/roster/rows: one validated manual entry | D2 |
| POST /api/institutions/[id]/approve: allowlisted demo bootstrap only | D2 |
| PATCH /api/role-grants/[id]: revoke/replace scoped grant | D2 |
| GET /api/me/contexts: active institution/role contexts | D2 |
| POST /api/incidents/[id]/duplicate-link: canonical ID + version | D3/D1 policy |
| POST /api/incidents/[id]/cancel: reason + version; may return approval-needed | D3/D4 policy |
| POST /api/incidents/[id]/reopen: reason + version | D3 |
| PUT /api/incidents/[id]/feedback: resolutionVersion/rating/comment | D3, P1 |

Add section/seat fields and active-seat uniqueness to grants; add lifecycle timestamps/resolution version, cancellation requests via approvals, stable logical_task_key/carried_from_task_id, designated_verifier_membership and verifier deadline. Add incident_feedback with unique incident/resolution version/reporter. Reuse audit/events; do not build a second event system.

## 8. Workload balancing and dependency handoffs
| Deliverable | Implementer | Reviewer |
| --- | --- | --- |
| Shared schemas/provider wrapper/runner, Commander and worker | D1 | D2 auth checks; D4 transitions |
| Identity SQL/policy draft and tests | D2 | D1 integrates/applies |
| Triage module + schema/fixture tests | D3 | D1 |
| Verification module + evidence tests | D4 | D1 |
| Specialist module using configured profiles | D5 | D1 |

This is allocation to the five human developers' coding assistants, not permission for uncontrolled subagents.
D1 publishes agent function signatures and tool interfaces by minute 30. Each module accepts authorized context, calls the common provider, returns validated typed output and never bypasses tool enforcement.
By hour 2 each module owner delivers one fixture test and reports live-provider readiness; D1 integration is continuous. Avoid parallel edits to shared generated types.
If D5 email provisioning is blocked, D1 helps unblock accounts while D5 can implement its module against the agreed adapter. Never postpone delivery testing to the final hour.

## 9. Additional acceptance tests
- CORE-01 D2: create college from UI, approve, add room/roster, join and authorize CR without relying only on seeds.
- CORE-02 D2: two seats, replacement, revoked session and role-context switch.
- CORE-03 D3/D1: duplicate privacy/cycle/unique vote rules.
- CORE-04 D3/D4: safe cancellation, reopening cutoff, stale jobs and missing-verifier escalation.
- CORE-05 D1/D4: verified work carried only when unchanged; active tasks reconciled.
- CORE-06 D1/D5: measure new-report-to-email and failed-verification-to-new-plan latency on deployed build; adjust demo to actual time.
- CORE-07 D3: feedback scoped/unique/no closure mutation (P1).
- CORE-08 All: only each developer's owned paths changed; clean integration build on shared main branch.

