# Developer 5 — Shared UI, Real Email, Timeline and Demo
Read the master, contracts and verification file. Own shared presentation, email/outbox adapter, webhook processing, email confirmation page, notifications and demo production. Email is a Part A priority; 3D is optional.

## Working protocol
One task, one verification, then developer approval. Before implementing UI ask for uploaded layout/template, desired navigation, colors/type, mobile states and supplied assets. Confirm ORION full form and the user's actual intro idea; do not present the proposed branding as an established decision.
Do not change another developer's route/service. Share components and contracts.

## Part A — Prove communication early (0–2 hours)
### A1. Real email smoke test
Configure a permitted sender and real team-controlled recipients. Check provider restrictions and domain readiness. Send a harmless test through the server adapter and inspect actual inbox plus provider status.
Accept: a genuine message arrives; credentials remain server-only.
Verify: record provider message ID privately and a sanitized test result. If blocked, notify D1 immediately; do not label a mock as delivered.
Auth login mail is a separate D2 integration.

### A2. UI intake and shared shell
Get the user's reference and establish tokens, navigation shell, responsive patterns and loading/error/empty states. Publish reusable components to D2–D4.
Accept: core dashboard supports keyboard and mobile; role navigation is consistent, but server authorization remains the security boundary.
If references are missing, ask for explicit permission before using a minimal fallback.

### A3. Durable outbox integration
Implement templated generic case notifications from database outbox entries. Support idempotency, bounded retries and controlled demo recipient allowlisting.
Accept: duplicate job execution does not create duplicate logical mail; private complaint contents are excluded.
Verify: transient failure, invalid recipient and repeated worker execution.

## Part B — Honest delivery and safe actions (2–5 hours)
### B1. Provider webhooks
Verify signatures against raw body, deduplicate event IDs and tolerate out-of-order events. Model queued/sent/delivered/failed/bounced truthfully.
Accept: sent means provider acceptance; delivered means recipient server acceptance, not that the person read it.
Verify: forged signature, duplicate delivered event and late event do not corrupt status.

### B2. Secure email acknowledgement
Create expiring signed action links scoped to identity, assignment version and nonce. GET opens a confirmation page only. Login and deliberate POST call D4's shared acknowledge service; atomically consume the token.
Accept: mail link scanners cannot acknowledge a task and forwarding a link does not grant another user authority.
Verify: GET has no mutation; expired, reused, wrong-user and stale-assignment tokens fail.
Coordinate login return path so the intended staff member can finish confirmation.

### B3. Timeline and notifications
Render persisted agent decisions, tool outcomes, plan versions, assignments and evidence status with role-filtered payloads. Keep notifications separate from proof of real email delivery.
Accept: users can see what changed and why at a concise level; confidential content is redacted per viewer.
Verify: new plan appears without a fabricated animation; delivery failure is visible; another tenant receives nothing.

## Part C — Demo readiness, then optional intro (5–7.5 hours)
### C1. End-to-end communications QA
Test actual deployment, inbox arrival, webhook transitions and authenticated confirmation. Check phone layout, accessibility and error states.
Accept: D1 can demonstrate a real newly generated notification and worker action.
Deliver email evidence/test results and UI limitations to README owner.

### C2. Optional user-approved ORION intro
Only after the core flow and mail work, spend at most 45 minutes implementing the approved intro. Proposed fallback: short orbiting-node wordmark, not a required design.
Ask for assets/layout and confirmed full form. Include immediate Skip, reduced-motion/static fallback and a fast mobile path. Do not block login or operations on 3D loading.
Accept: skip and reduced motion work; the intro does not consume the three-minute demo.
If time is tight, defer entirely rather than claim a completed 3D experience.

### C3. Record and package the demo
Follow 08's three-minute script. Capture the actual deployed build and genuine AI/action evidence; label fixtures or accelerated time. Avoid secrets and private student data.
Accept: video link plays publicly and has audio/captions as available; give link to D1 for README/submission.
Do not use fabricated traces or prerecorded results as if they were the live system.

## Revision 2 — integrate into existing parts
Read 09 and 10 before execution.
- A2: render D2's authorized context selector in shared shell. Only display granted contexts.
- A3: own src/server/agents/specialist.ts with D1's provider/types; use category profiles, eligible staff facts and bounded action schema. One configurable module, not one service per department.
- B3: reflect linked cases and carried-forward tasks honestly in the timeline; never show stale jobs as new successful actions.
- C1: measure real email/agent latency with D1 (CORE-06). Keep quick processing browser-independent; adapt demo to actual results.
- C2: intro remains P2, not a blocker for core operations or mandatory mail tests.

