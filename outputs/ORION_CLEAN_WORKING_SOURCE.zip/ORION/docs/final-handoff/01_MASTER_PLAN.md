# ORION - Revised Master Implementation Plan
Working full form: **Operational Response & Intelligent Orchestration Network**.
Owner: Shashank / Developer 1. Team: five AI-assisted developers using Antigravity.
Read alongside [technical contracts](02_TECHNICAL_CONTRACTS.md) and [verification plan](08_VERIFICATION_DEMO_SUBMISSION.md).

## 1. Goal and agreed decisions
ORION is a multi-college, role-based campus platform whose four AI agent types coordinate incidents from report to verified resolution. The UI is the control panel, not the autonomous capability itself.

Confirmed behavior:
- Principal creates the college and authorizes admins, HODs and presidents/coordinators.
- Admins maintain departments, blocks, floors, rooms, labs and basic equipment counts.
- HODs authorize CRs by department, section and term; supervisors manage operational staff.
- CRs raise routine department incidents; eligible department students vote once.
- Every verified student can privately report safety issues and complaints against CRs.
- Verified transport users can raise route-related complaints even if not CRs.
- Authorized club presidents raise club requests; term expiry removes that authority.
- Staff control Available / Busy / Off duty; admins control institution membership Active / Inactive.
- Staff submit work for verification, not direct closure.
- Photos do not prove an internal repair works. Appropriate human checks are required.
- Four separate AI modules: Triage, Commander, Specialist and Verification.
- Real email goes only to controlled test inboxes during the hackathon.
- UI templates come from developers/users. Ask before implementing each new screen family.
- Premium UI and optional 3D introduction remain important, but cannot replace working logic.

## 2. Timing and compliance
The latest user-supplied rules explicitly require Featherless.ai, fresh event-built code, public reviewability and a three-minute video. Incremental Git history is our engineering practice, not a requirement verified from those rules. Plan for a deployed app because deployment wording is inconsistent and the stricter section requires it. The page describes two judging rounds and top-15 live demos.

The 9 AM-6:30 PM window equals 9.5 hours; it conflicts with the two-day description and earlier 16-hour request. Ask organizers for written clarification. Do not assume overnight coding is authorized. Hours below are relative to the confirmed opening. If the actual window is shorter, reserve the final 90 minutes for testing/submission and cut optional scope first.

Planning documents may exist beforehand; application code/assets must follow event rules. AI-generated code still requires meaningful team review, testing and understanding.

## 3. Deliverable levels
### P0: never cut
- Tenant-scoped identity and role checks; basic principal-created college, department/room setup and manual roster entry plus real role-authorization flow. Seeded data supplements, never replaces, this flow.
- CR report, department vote, private safety/CR report.
- Four Featherless-powered agent modules with structured state and tool actions.
- Eligible staff selection, availability control, assignment and acknowledgement.
- Real assignment email with truthful delivery evidence.
- Persistent background SLA monitoring without an open browser.
- Staff evidence, manual confirmation, failed-verification reopening and revised plan.
- Visible safe audit timeline, approvals, test coverage, deployment, README and demo video.

### P1: deliver after P0 gate passes
- Advanced college configuration and bulk CSV import; basic setup and manual roster entry are P0.
- Thin transport and club screens using shared incident primitives, not separate products.
- Campus location tree, asset counts and simple department metrics.
- Additional specialist profiles beyond the flagship facilities/electrical/security path.

### P2: time-boxed polish
- Custom 3D intro, visual map, enhanced charts and extra animation.
- Keep routes/data contracts for deferred modules, but label them unavailable instead of presenting fake functionality.

## 4. Authority and privacy
Membership and role grants are institution-scoped, never user-editable authorization metadata.
- Principal: appoint admins/HODs/leadership; campus-wide authorized approvals.
- Admin: college configuration and scoped user management.
- HOD: CR terms, department oversight, reasoned overrides and escalation.
- Supervisor: staff administration within assigned service department.
- CR: routine reporting and suitable verification; no access to accusations about themselves.
- Student: public department reads/votes, private direct reports, verified transport reporting.
- Staff: own eligible assignments, work availability, updates and evidence.
- Transport admin: transport membership and route issues.
- President/coordinator: club requests and term oversight.

Routine complaints: public to eligible institution/department members, not the internet.
Confidential cases: reporter plus explicit case recipients; exclude the accused from authorization even if they hold a supervisory role. If all normal recipients conflict, route to a non-conflicted principal/designated safeguarding officer. If none exists, hold access restricted and require authorized external handoff; never auto-disclose.
AI handles confidential-case intake/routing, not guilt, discipline or case closure.

## 5. Registration
Principal enrollment creates a pending institution. For the hackathon, the team lead approves demo institutions using a server-only allowlisted bootstrap process. It is not production proof of institutional authority.
Student joins only an existing approved college. Match college + roll number to an approved roster. Require OTP to the roster-linked email, or administrator review when no email is on record. Verifying any arbitrary email is not proof of owning a roll number.
Role invitations and grants include institution, department/section/club, term and granting actor. No self-promotion. Multi-role users switch only among granted contexts.
Account/member deactivation must block the next protected request using fresh database checks, even if a JWT remains valid.

## 6. Incident workflow and agent responsibilities
1. Authorized report saves incident and job atomically; urgent safety flag immediately notifies designated humans without waiting for AI/votes.
2. Triage receives text and authorized campus context. It proposes categories, risks, missing details and duplicate candidates. Photos remain human-reviewed evidence under the text-only model.
3. Commander creates a versioned plan: priority, relevant specialists, tasks, dependency order, evidence requirements and approval gates.
4. Specialist instances use department profiles to select eligible staff and request bounded actions through validated tools.
5. Human staff acknowledge, start, report blocked work and submit evidence.
6. Verification module checks structured notes/checklists; designated humans inspect images and perform functional tests. Deterministic closure rules require both appropriate evidence and authorized confirmation.
7. Failure invokes Commander with the failure reason and current state. Version 2 must change an assignee, task, dependency, evidence requirement or escalation. Merely rewording a plan is not a successful replan.
8. Close only when all required tasks verify; no response from a verifier means pending verification plus reminder/escalation.

Agents use distinct prompts/schemas/tool permissions even when using one underlying model. They do not need four different models. Native tool calls or validated action JSON are both acceptable; neither may directly run arbitrary code or SQL.

## 7. Policy defaults for the demo
These are demonstration defaults, not campus emergency-response standards.
- Severity: critical > high > normal > low. Safety policy establishes a minimum severity; AI cannot downgrade below it without authorized review.
- Within equal severity, critical location/impact, recurrence, waiting time and unique votes inform order.
- One vote per eligible member per incident. New votes may trigger a debounced reprioritization job, not a full rerun for every click.
- Routine acknowledgement reminder at 10 minutes, escalation at 20 minutes; actual response policy must be approved before a real pilot.
- Demo-only control can advance a selected due job, labeled 'Simulated deadline'. The background worker still executes the real action.
- Maximum three AI attempts per job and three plan versions per incident before HOD/manual handoff.
- Maximum one acknowledgement reminder followed by one supervisor escalation per assignment version.
- High-risk physical actions require authorized approval and qualified human execution. Staff cannot use the app as a substitute for emergency procedures.

## 8. Staff availability integrated
- Active + Available + correct skill/zone + capacity: eligible for routine work.
- Busy: excluded from routine work; urgent proposal requires supervisor approval before another assignment.
- Off duty or inactive membership: never eligible for new work.
- Default new staff to Off duty; workload limit defaults to one active task in the demo.
- Staff changing off duty with open work must choose Keep current tasks or Request handover. Handover retains an accountable owner until replacement/supervisor acceptance; never silently drops a task.
- Deactivation blocks access and sends unfinished work to a supervisor/Commander handover queue.
- Recheck eligibility atomically at assignment time, not only during agent lookup.
- Log actor, previous/new values, time and reason where required.

## 9. Real communications
See contracts for delivery states and endpoint ownership.
Assignment -> transactional outbox -> provider acceptance -> verified webhook -> delivered/bounced/failed state.
Delivered means recipient server accepted it, not that a human read it.
Acknowledgement is a separate authenticated confirmation action.
Email link GET opens a page; only a deliberate POST may accept the task. This avoids email scanners accepting work.
Signed expiring action tokens, current assignee checks, replay protection and recipient allowlists are required.
Confidential email contains only a generic notification and authenticated link, never allegations or evidence.

## 10. UI and ORION intro
Each developer's agent first asks for the uploaded template, role/route, mobile layout, interactions, all data states, assets and accessibility requirements. Inspect the upload. Ask before changing its composition.
If no template exists, ask permission to use Developer 5's shared fallback; do not silently invent a competing design. Backend work can continue while awaiting reference.
Fallback: navy/graphite, high-contrast readable text, cyan active intelligence, amber attention, red danger, restrained motion.
A proposed intro (subject to user approval): four agent nodes orbit an incident pulse, connect, resolve into ORION, reveal the full form. Maximum 5-7 seconds, immediately visible Skip, no autoplay audio, reduced-motion/static fallback. Load only on landing, never dashboard.
Short-window budget: 45 minutes after core visual components and real email work pass. Do not force a custom intro without the user's actual idea/reference.

## 11. Provisional 9.5-hour execution
| Time | Gate and parallel work |
|---|---|
| 0:00-0:30 | Confirm rules/accounts/UI; lead creates shared app/contracts; everyone receives one task |
| 0:30-2:00 Part A | Schema/RLS foundation, real Featherless smoke test, identity shell, reporting shell, operations shell, email/domain/webhook smoke test; deploy skeleton |
| 2:00-5:00 Part B | Connect report -> Triage -> Commander -> Specialist -> assignment; persist jobs; staff availability and acknowledgements; real inbox receipt |
| 5:00-7:30 Part C | Verification failure -> replan; private access tests; background reminder; scope-dependent transport/clubs and intro; integrate continuously |
| 7:30-8:30 | Feature freeze; permission, race, retry and end-to-end checks; repair only |
| 8:30-9:15 | Record 3-minute video; README actual features; live deployment and clean-session checks |
| 9:15-9:30 | Submission form, links, commit SHA and receipt verification; no speculative changes |

Integrate passing slices at least hourly, not only at Part ends. Lead carries architecture/agents/security/integration; do not leave all merge work for the end.

### If organizers explicitly permit 16 hours
Keep P0 by Hour 7.5. Use 7.5-10 for complete onboarding, transport/clubs and extra specialist profiles; 10-12 for approved 3D/map/metrics; 12-14 for tests/security/reliability; 14-15 for video/README; 15-16 for submission buffer. No optional extension is authority to code beyond official hours.

## 12. Scope-reduction gates
- At Hour 2: if real provider/email setup fails, escalate setup immediately; no 3D work until a real test succeeds.
- At Hour 5: if report-to-assignment is not deployed, defer charts, maps, CSV importer, broad club/transport UI and 3D.
- At Hour 7.5: freeze additions. Preserve four real agent steps, failed verification, permissions and real email proof.
- In-app outbox and mock agents keep a fallback demonstration usable, but cannot be passed off as live delivery or mandatory Featherless integration.
- If P0 still fails, report the actual limitation; do not hide it with prewritten success events.

## 13. Team workflow
Give each coding agent master + contracts + its developer file + verification doc. One task at a time; state acceptance, implement, verify, explain, commit, then wait for developer approval.
One branch and separate local checkout per developer; only lead integrates shared files and migrations. Never run five branch-switching agents in one shared checkout. No unrelated rewrites. All agents must inspect existing code before scaffolding.
A task handoff includes commit SHA, changed paths, tests/results, API changes, screenshots where relevant, blockers and next dependency. Never include secrets.
The lead must be able to explain tool authorization, live model calls, background processing and the verification loop during Q&A.

## 14. Final handoff requirements
Read [execution decisions](09_EXECUTION_DECISIONS.md) for the category matrix, duplicate policy, lifecycle transitions, role replacement and feedback contracts. These are part of this master plan, not optional suggestions.
Read [Antigravity launch instructions](10_ANTIGRAVITY_HANDOFF.md) before executing a task. Developer 1 owns Commander, shared agent runner and review; D3 implements Triage, D4 Verification, and D5 the configured Specialist module under D1's published schema. D2 drafts identity migrations/policies for D1 review and application. These specific module assignments supersede earlier blanket references to all agents being implemented by D1.
P0 includes two CR seats per section, role-context switching, safe cancellation/reopening, missing-verifier escalation, plan carry-forward and duplicate linking. Simple post-resolution feedback is P1. No additional agent types are required.
