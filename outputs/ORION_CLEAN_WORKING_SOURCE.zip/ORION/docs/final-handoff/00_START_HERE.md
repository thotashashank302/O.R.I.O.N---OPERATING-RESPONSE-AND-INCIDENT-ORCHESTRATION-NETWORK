# ORION Revised Implementation Package
Revision 2: 4 September 2026. Status: reviewed implementation handoff, not a completed application.

## Read order
1. [Master plan](01_MASTER_PLAN.md)
2. [Technical contracts and repository structure](02_TECHNICAL_CONTRACTS.md)
3. Your developer plan:
   - [Developer 1 - Team Lead](03_DEVELOPER_1_LEAD.md)
   - [Developer 2 - Identity](04_DEVELOPER_2_IDENTITY.md)
   - [Developer 3 - Reporting](05_DEVELOPER_3_REPORTING.md)
   - [Developer 4 - Operations](06_DEVELOPER_4_OPERATIONS.md)
   - [Developer 5 - Experience and Communications](07_DEVELOPER_5_EXPERIENCE_COMMS.md)
4. [Verification, demo and README](08_VERIFICATION_DEMO_SUBMISSION.md)
5. [Required execution decisions and gap closures](09_EXECUTION_DECISIONS.md)
6. [Paste-ready Antigravity handoff](10_ANTIGRAVITY_HANDOFF.md)

This package supersedes the earlier 16-hour plan and separate availability addendum for implementation. Old files remain preserved as history. Staff availability and email delivery are now integrated into the primary developer tasks.

## Confirm before coding
- Organizer-confirmed build start and submission deadline. The supplied rules say September 4-5, 9 AM-6:30 PM and approximately eight hours. They conflict with the earlier 16-hour assumption. This package uses a provisional 9.5-hour maximum, not a confirmed event schedule.
- Five names mapped to Developers 1-5; Developer 1 is Shashank.
- Real team-controlled inboxes; access to Featherless, database, hosting and email accounts.
- UI reference uploads and the actual desired ORION intro. The full form below is a proposed working name, not previously supplied branding.
- Sender/domain and auth-email delivery tested; never assume a testing sender can deliver to arbitrary recipients.
- Exact submission platform/form confirmed with organizers. Do not assume Devpost or that platform problem-scoring instructions apply to this build.

## Antigravity instruction to paste
Read this package's master plan, technical contracts, your developer file and verification document. Work only in your assigned ownership area. Present the next numbered task, its files and acceptance test. Before UI implementation, ask me for my layout/template and missing requirements. Implement one task, test it, summarize what changed and wait for my approval before proceeding. Never change shared contracts, dependencies, migrations or another developer's files without lead approval. Never put credentials in code or fabricate successful AI/email/test results.

## Important limitations
- Featherless.ai must power real application reasoning; an IDE using AI does not satisfy application integration.
- The initial Llama model is text-only. Photos are private evidence for humans, not automatically interpreted by this model.
- Safe autonomous coordination is in scope; physical repairs, emergency response and sensitive-case decisions remain human responsibilities.
- All application code and original assets must be created inside the confirmed allowed build window.
- If existing code already exists, inspect it and adapt these plans; do not overwrite it or re-scaffold blindly.
