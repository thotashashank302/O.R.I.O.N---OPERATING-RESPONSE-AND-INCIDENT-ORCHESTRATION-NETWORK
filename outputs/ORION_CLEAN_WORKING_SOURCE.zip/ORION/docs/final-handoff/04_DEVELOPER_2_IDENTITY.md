# Developer 2 — Identity, College Setup and Role Administration
Read the master, technical contracts and verification file. Own identity, institutions, roster and role-management services/screens; do not edit shared migrations directly.

## Working protocol
One numbered task per agent turn; test and request approval before the next. Before UI work ask for the supplied layout/template, navigation, mobile behavior and missing states. Submit schema changes to Developer 1. Reuse the agreed design tokens.

## Part A — Secure entry (0–2 hours)
### A1. College-scoped registration and session checks
Implement authentication and roster-bound registration using college, unique roll number and verified matching email. Students cannot join a nonexistent college or gain authority from editable metadata. Configure/test auth-email delivery separately from incident mail.
Accept: successful login gives only approved college membership; roll number alone cannot impersonate a student.
Verify: duplicate roll, wrong email, unregistered college and a second tenant.

### A2. Principal bootstrap and authorization
Implement the explicitly allowlisted demo principal bootstrap, visibly documented as demo-only. Principal creates the college and grants admin/HOD/president authority. HOD can appoint CRs only within their department/class/term.
Accept: user self-selection never grants staff, principal or president access.
Verify: forged role requests, expired grants, cross-department appointments and inactive sessions.
Handoff: publish approved test identities to the team through a private channel, not README passwords.

### A3. Administration UI
Ask for the admin reference before building. Show pending membership/role requests, authorization decisions, membership Active/Inactive, and clear empty/error/loading states.
Accept: membership activation is separate from staff availability; deactivation is enforced server-side immediately.
Verify: deactivate a logged-in test account, then attempt an API action.

## Part B — Operational identity (2–5 hours)
### B1. Campus configuration
Build minimal department/block/room/lab/equipment metadata forms. Validate location belongs to the college and maintain stable IDs for incident references.
Accept: reporters select valid locations; editing labels does not break historical incidents.
Verify: invalid parent IDs, cross-tenant location changes and basic mobile forms.

### B2. Staff and confidential-case eligibility
Maintain staff skills, department and service zones. Start staff Off duty until explicitly changed. Expose eligible identity data to D1/D4 without allowing staff to edit their own authority.
Coordinate confidential-case access rules: accused staff or CR cannot see or route their own complaint; define authorized alternate reviewer.
Accept: inactive users are excluded regardless of an old Available state.
Verify: private case ACL, revoked membership and out-of-department staff.
Handoff: D4 owns availability interactions; D1 owns final assignment eligibility enforcement.

### B3. Transport and club authority
Implement verified transport enrollment/route and term-scoped club president grants. Self-reported bus usage is a request, not proof of entitlement. Permit authorized transport users to report route issues without being CRs.
Accept: D3/D4 can use clear authorization helpers; expired presidents lose privileged actions.
Verify: non-rider request, wrong route and expired club term.
If behind, preserve backend eligibility and use minimal forms; postpone roster import polish.

## Part C — Hardening and handoff (5–7.5 hours)
### C1. Test the complete role matrix
Run the identity/privacy tests in 08 with real ordinary-user sessions. Cover college isolation, principal/admin/HOD boundaries, CR scope, student emergency exception and staff deactivation.
Accept: every role's allowed and denied action has evidence; do not rely on hidden buttons as security.

### C2. Finish essential administration states
Complete approval feedback, roster errors and safe account handling. Never expose private credentials in a demo user picker. Seed test identities only via the lead-approved script and account setup.
Accept: controlled demo identities are usable and authorization is genuine.

### C3. Deliver documentation
Give D1 setup instructions, role matrix, known limits and identity test results for README. Help test deployed login and authorization.
Scope cut: defer bulk CSV convenience and rich college editors before security or the core role flow.

## Revision 2 — integrate into existing parts
Read 09 and 10 before execution.
- A1: basic principal-created institution and manual roster entry are P0, not seed-only substitutes. Draft identity schema/RLS SQL for D1 review; never apply shared migrations independently.
- A2: implement two numbered CR seats per section/term, revocation/replacement and pending-verifier reassignment. Do not require storing gender to enforce seats.
- A3: implement authorized context state and share context-switch data with D5; test old sessions after revocation.
- B1: configure category-to-department/alternate-verifier mapping from 09, including separate IT capability and actual emergency contacts.
- C1: run CORE-01/02 and identity migration negative tests; provide evidence to D1.

