# ORION Technical Contracts - Shared Source of Truth
Developer 1 owns changes. Read with [master plan](01_MASTER_PLAN.md).
This document is an intended interface, not generated source code.

## 1. Stack and secrets
- Node.js 22+; Next.js App Router + React + TypeScript + Tailwind. Lead pins installed versions and commits one lockfile. Do not independently upgrade.
- Supabase hosted Postgres/Auth/private Storage. Use verified server auth and current membership checks; never authorize using editable user metadata.
- Featherless OpenAI-compatible Chat Completions via one server adapter. No Gemini SDK/key substitution.
- Resend + HTTPS webhook for email.
- Persistent database jobs + Supabase Cron every minute invoking a protected Node route. No browser timer dependency.
- Vitest for logic/integration fixtures; Playwright for browser flows.
- Three.js/React Three Fiber lazy loaded only for optional approved intro.
- Vercel hosting; lead verifies its actual function timeout permits the bounded worker. Do not assume a plan's time limits.

Environment names:
```dotenv
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=
SUPABASE_SECRET_KEY=
APP_URL=
FEATHERLESS_API_KEY=
FEATHERLESS_BASE_URL=https://api.featherless.ai/v1
FEATHERLESS_MODEL=meta-llama/Llama-3.3-70B-Instruct
RESEND_API_KEY=
RESEND_FROM=
RESEND_WEBHOOK_SECRET=
EMAIL_ACTION_SECRET=
AUTOMATION_SECRET=
DEMO_MODE=false
DEMO_RECIPIENT_ALLOWLIST=
DEMO_ADMIN_EMAILS=
```
Only the two NEXT_PUBLIC values are client-exposed. Use a supported server secret/service credential name consistently if the project still uses legacy keys; never expose either in a client bundle.
Share real credentials through private environment configuration, not plans, commits, screenshots or prompts.

## 2. Featherless integration
Call POST /v1/chat/completions at the configured base URL with Bearer API key and the exact model ID. Start with meta-llama/Llama-3.3-70B-Instruct only after confirming hackathon-account access, latency and valid output. The official catalog lists tool calling; account access is not guaranteed.
All four logical agents may use this model. Distinct instructions, output schemas, allowed tools and state define the agents.
Use temperature 0.1 as a project default; validate every response with Zod. Do not assume strict JSON-schema mode is supported: test it; otherwise request JSON and validate/retry with a bounded repair call.
Begin at concurrency one to respect unknown account limits. On 429/5xx schedule a retry with backoff; do not spin.
Text-only MVP: do not send image URLs expecting vision. Store photos privately for human reviewers. Automatic vision is an optional later integration only after a real capability test.
Persist agent name, model/provider, prompt version, latency, execution status and validated outcome. Store no hidden chain-of-thought. Redact confidential inputs from logs.
If Gemini code exists, adapt request/response/tool-call parsing rather than replacing the key alone.
One live smoke test must succeed for each agent before claiming the four-agent flow works.

## 3. Repository ownership
```text
orion/
  docs/                         plans, API contract, test evidence, demo guide
  public/branding/              approved assets only
  src/app/
    (public)/page.tsx           landing - D5
    (auth)/login/page.tsx       D2
    (auth)/register/page.tsx    D2
    auth/callback/route.ts      D2, D1 reviews
    (dashboard)/layout.tsx      D1 auth + D5 shell
    (dashboard)/principal/     D2
    (dashboard)/admin/         D2
    (dashboard)/student/       D3
    (dashboard)/cr/            D3
    (dashboard)/hod/           D4
    (dashboard)/staff/         D4
    (dashboard)/transport/     D3 user + D4 admin components
    (dashboard)/clubs/         D3 request + D2 leadership components
    (dashboard)/incidents/[id]/ D3 route composing D4/D5 components
    (dashboard)/email-actions/confirm/ D5
    api/                       endpoint ownership below
  src/features/
    identity/ institutions/ role-management/    D2
    reporting/ voting/ private-complaints/      D3
    operations/ staff-availability/ resolution/ D4
    intro/ notifications/ agent-timeline/       D5
  src/components/ui/           D5
  src/components/layout/       D5
  src/contracts/               D1
  src/server/
    auth/ db/ policies/        D1
    agents/                    D1 runner/commander; D3 triage; D5 specialist; D4 verification
    orchestration/             D1: runner, state machine, jobs, timers
    email/                     D5
    identity/                  D2 domain services
    reporting/                 D3 domain services
    operations/                D4 domain services
  supabase/migrations/          D1 only
  scripts/seed-demo.ts          D1, D2 supplies roster fixture
  tests/unit/                  feature owner
  tests/integration/           feature owner + D1
  tests/e2e/                   D5 suite with all owners
```
No page.tsx and route.ts for the same resolved URL. Shared shell/auth/type/migration changes require lead approval. API handlers are thin and delegate to domain services; no generic unauthenticated email-send or arbitrary SQL endpoint.

## 4. Core data model
All tenant-owned rows include institution_id. IDs are UUIDs; times are UTC, displayed in Asia/Kolkata. Enforce same-institution references in database constraints/service checks, not client filtering.

| Table | Required purpose/fields |
|---|---|
| institutions | name, unique code, approval state, approved_by |
| departments | institution, name, academic/service kind |
| campus_locations | institution, parent, block/floor/room/lab kind, label, asset_counts |
| profiles | auth user ID, display name; no global role |
| institution_memberships | user, institution, active/inactive, unique user/institution |
| role_grants | membership, role, department/section/club scope, starts/ends, granted_by, revoked_at |
| student_roster | institution, unique roll number, roster email, department/year/section, claimed_user |
| staff_capabilities | membership, skills, zones, availability enum, workload_limit, updated_by/at |
| transport_enrollments | membership, route/bus, verified_by, active |
| clubs / club_terms | institution, club, president/coordinator membership, start/end |
| incidents | reporter, reporting_scope, category, visibility, location, description, severity, state, version, parent_duplicate_id |
| incident_votes | incident, membership, unique incident/membership |
| incident_case_access | confidential incident, allowed membership; excluded accused identities |
| incident_plans | incident, unique version, explanation, status |
| incident_tasks | plan, specialist profile, checklist, state, evidence requirements |
| task_dependencies | task, prerequisite; same plan, no cycles |
| assignments | task, assignee, state, acknowledgement deadline, active version |
| approvals | action payload hash, plan version, approver, decision/time |
| resolution_evidence | task, uploader, kind, private storage key or structured test result |
| verification_records | task, evidence version, human result, agent verdict, reasons |
| jobs | type, incident, due_at, status, attempt, lease_until, dedupe_key |
| agent_runs / incident_events | outcome + safe actor/action timeline; append-only application access |
| email_outbox | assignment/version, recipient, idempotency key, provider ID, transport state |
| email_events | unique provider event ID, type, happened_at, processed_at |
| email_action_tokens | hashed nonce, assignment/version, intended membership, expiry, consumed_at |
| notifications | recipient membership, safe text/link, read_at |
| audit_events | membership/role/availability changes outside an incident |

D1 owns migrations and generated DB types; D2 proposes identity fields, D3 reporting, D4 operations, D5 email. No developer independently applies migrations to shared database.
Expose only required tables; pair explicit API grants with RLS. Test SELECT/INSERT/UPDATE separately. User updates must not change institution, role or ownership. Private storage uses short-lived signed access after current authorization.

## 5. Status contracts
Membership: active | inactive.
Availability: available | busy | off_duty.
Incident: reported | triaging | needs_clarification | planned | awaiting_approval | assigned | acknowledged | in_progress | submitted_for_verification | resolved | reopened | escalated | cancelled.
Task: pending | ready | assigned | acknowledged | in_progress | blocked | submitted | verified | failed | cancelled.
Assignment: offered | acknowledged | active | handover_requested | released | completed | cancelled.
Job: queued | running | succeeded | retry_wait | dead.
Email: queued | sending | sent | delivered | failed | bounced | suppressed. Acknowledgement is an assignment field, not an email delivery state.
Incident state derives from task/approval progress. One verified task cannot close a multi-task incident.
Every state-changing request includes expectedVersion; mismatch returns 409 and latest safe state.

## 6. HTTP contract and ownership
JSON success: {data, requestId}; error: {error:{code,message},requestId}. Use 401 unauthenticated, 403 unauthorized, 404 inaccessible resource when privacy requires, 409 stale/duplicate conflict, 422 validation, 429 limits.
Authenticated mutations check origin/CSRF protection, current membership, scope and input schema. Never accept caller-supplied actor role.

| Endpoint | Input/result | Owner |
|---|---|---|
| POST /api/institutions | name/code -> pending institution | D2 |
| GET/POST /api/locations | scoped list/create location | D2 |
| POST /api/roster/import | validated CSV/rows -> counts/errors, no secrets | D2 |
| POST /api/memberships/claim | institution/roll -> verified roster claim | D2 |
| POST /api/role-grants | member/role/scope/term -> grant | D2 |
| PATCH /api/memberships/[id]/status | active/inactive + reason/version | D2 |
| POST /api/transport/enrollments | route/member -> pending/verified enrollment | D2 |
| POST /api/club-terms | club/member/term -> grant | D2 |
| GET/POST /api/incidents | eligible list / report -> incident + queued job | D3 |
| GET /api/incidents/[id] | authorized incident + safe task/event projection | D3 |
| POST /api/incidents/[id]/clarifications | answer/version -> resumed job | D3 |
| PUT/DELETE /api/incidents/[id]/vote | idempotent eligible vote/remove | D3 |
| POST /api/uploads | type/size/incident -> private upload authorization | D3, D4 reuses |
| POST /api/incidents/[id]/confirm | fixed/not_fixed + reason/evidenceVersion | D3 |
| GET /api/assignments | scoped queue | D4 |
| POST /api/assignments/[id]/actions | acknowledge/start/block/submit/handover + version | D4 |
| PATCH /api/staff/me/availability | state, openTaskChoice, version -> saved state | D4 |
| POST /api/tasks/[id]/evidence | note/test/storage reference -> evidence version | D4 |
| POST /api/approvals/[id]/decision | approve/reject + action hash/version/reason | D4 with D1 enforcement |
| POST /api/incidents/[id]/override | reasoned reassign/priority correction | D4 with D1 policy |
| GET/PATCH /api/notifications | own list / mark own notification read | D5 |
| POST /api/email-actions/confirm | nonce/token + authenticated confirmation | D5 -> D4 service |
| POST /api/webhooks/email | signed raw provider payload -> recorded event | D5 |
| POST /api/automation/tick | scheduler secret -> bounded claimed job result | D1 |
| POST /api/demo/advance | demo admin + chosen job -> due_at=now with simulation log | D1 |

Routine reporting scope: CR department; transport scope: verified route users; club scope: active president; confidential: any verified member. Vote scope follows department or route membership, never confidential.

## 7. Agent schemas and tool limits
TriageResult: category, secondaryRisks[], locationId|null, impactSummary, confidence, clarification|null, duplicateCandidateIds[].
IncidentPlan: priority, explanation, specialists[], tasks[{localId,profile,goal,dependsOn[],evidencePolicy,requiresApproval}], acknowledgementMinutes.
SpecialistAction: taskId, candidateStaffId, checklist[], evidenceRequired[], communicationType.
VerificationDecision: taskId, verdict, missingEvidence[], reasons[], suggestedReplanReason|null.
Cross-check all IDs against authorized context. Validate acyclic graph, allowed action types and a maximum of five tasks per demo plan.
Tools: getIncidentContext, findRelatedIncidents, getEligibleStaff, createPlanVersion, assignTask, queueEmail, requestEvidence, requestApproval, escalateIncident, recordVerification.
Server enforcement applies even to service-key jobs. Never let a model directly set permissions, run code/SQL, contact arbitrary addresses, or mark a sensitive case resolved.

## 8. Worker and concurrency contract
Supabase Cron invokes the HTTPS tick route every minute using a server secret stored privately. Configure request timeout above the worker's bounded duration and verify on deployment.
Tick enqueues due SLA actions and invokes the same leased job runner used by immediate processing. Run one model step per job and persist its outcome and next job in a transaction. Process ready successor jobs immediately while the request has a measured safe execution budget; do not impose a one-minute delay between every agent. Stop cleanly before the hosting deadline, leaving remaining jobs persisted for the next invocation. Await processing within the request; never rely on detached promises after a response. Browser-independent recurring ticks recover unfinished work. Measure the full live sequence before promising the three-minute demo; if too slow, adjust the demo or use a supported durable worker, not fabricated instant events.
Use per-incident run locks, expected plan/evidence versions, unique dedupe keys and expiring job leases. A crash must permit recovery without duplicate email or repeated assignment.
Project default: 30-second AI timeout, three attempts with 1/2/4-minute backoff, then dead job + supervisor notification. Tune only after measured account latency and hosting limits.
Urgent human alerts and notification/outbox processing must not wait behind a slow AI job.
No off-browser claims until a test closes all dashboards and a scheduled event still executes.

## 9. Email contract
D5 configures allowed sender and test recipients, checks real inbox delivery early, and registers HTTPS webhook.
Provider accepted request -> sent, not delivered. Verify raw webhook signature with provider-supported verification before processing. Deduplicate event ID and retain event times; out-of-order 'sent' must not overwrite 'delivered'. Preserve bounce/suppression failures.
Resend can redeliver events. Outbox sending uses a stable idempotency key per assignment version/message type/recipient.
Action link contains assignment version, intended member, expiry and random nonce protected by server signature; store only nonce hash. Default expiry 24 hours.
GET displays confirmation only. POST requires matching authenticated member, current assignment, unconsumed token and active membership. Consume and acknowledge atomically. Duplicate confirmation is harmless; expired/reassigned links cannot act.
If sending outcome is uncertain, reconcile provider ID/idempotency result before retrying. Do not call in-app fallback 'delivered'.

## 10. Security and operational limits
- Private uploads: maximum three files/report, 5 MB each; JPEG/PNG/WebP only. Validate bytes and MIME server-side, randomize names, strip metadata on re-encode, no SVG/HTML. No arbitrary image-URL fetches.
- Normal reports: 5/member/hour; vote mutations: 30/member/minute; file attempts: 10/member/hour. Use persistent counters. Rate-limited safety UI still displays designated human emergency contacts.
- Treat user text, OCR, evidence and retrieved content as untrusted data, never agent instructions.
- Private cases never enter cross-case duplicate search or public analytics. Avoid sending unnecessary personal details to model provider.
- Membership inactivity is checked against database for every protected operation and storage authorization; invalidate UI caches. Global sign-out is only appropriate for global account compromise, not automatically for one institution.
- Approvals bind to action hash and plan version; a revised action needs new approval.
- Log request/job IDs and safe errors, not keys, tokens, entire private prompts or signed attachment URLs.
- Require authentication/role checks even if a route is hidden. Disable demo controls unless DEMO_MODE plus allowlisted active admin plus demo institution all match.

## 11. Official technical references
- Featherless API: https://featherless.ai/docs/quickstart-guide
- Starting model: https://featherless.ai/models/meta-llama/Llama-3.3-70B-Instruct
- Supabase Cron: https://supabase.com/docs/guides/cron
- Supabase security: https://supabase.com/docs/guides/database/postgres/row-level-security
- Supabase changes: https://supabase.com/changelog
- Resend webhook semantics: https://resend.com/docs/webhooks/introduction
- Resend verification: https://resend.com/docs/webhooks/verify-webhooks-requests
Technical details must be smoke-tested against the actual installed versions and account entitlements. No provider access has been tested by this document-generation task.

## 12. Required extended contracts
The additional tables/endpoints and policy decisions in [execution decisions](09_EXECUTION_DECISIONS.md) are required parts of this contract. Lead incorporates them into generated types before parallel development. Shared schemas live in src/contracts; each developer owns only their assigned agent module. D2 may draft identity migration SQL for review, but D1 alone integrates/applies shared migrations.
