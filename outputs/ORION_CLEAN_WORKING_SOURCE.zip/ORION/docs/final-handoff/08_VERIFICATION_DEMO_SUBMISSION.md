# ORION — Verification, Demo and Submission
This is an acceptance checklist, not proof that tests have already passed. Keep a result log with test ID, commit, environment, pass/fail, evidence and owner.

## Release gates
Developer 1 establishes these package scripts in Part A:
- npm run typecheck
- npm run lint
- npm run test
- npm run build
- npm run test:e2e

Run isolated integration tests against controlled test data. Never reset a shared or production database for tests. Fixture model responses are appropriate for deterministic tests but do not prove live Featherless behavior.

| ID | Required check and invariant | Owner |
| --- | --- | --- |
| ID-01 | Matching verified roster email is required; roll alone cannot claim another identity | D2 |
| ID-02 | Self-assigned privileged role, out-of-scope CR grant and expired club term denied | D2 |
| ID-03 | Ordinary user cannot read/write another college, including via direct API/storage | D1/D2 |
| ID-04 | Inactive membership blocks existing sessions and new assignments | D2/D4 |
| RP-01 | New CR report persists once and creates the autonomous job | D3/D1 |
| RP-02 | Duplicate/concurrent votes count once; urgent severity outranks votes | D3/D1 |
| RP-03 | Non-CR student can submit private emergency/CR complaint; accused denied access | D3/D2 |
| RP-04 | Verified rider and authorized president can report within their scopes | D3/D2 |
| RP-05 | Upload size/type/privacy and expiring access enforced | D3 |
| AI-01 | Real Featherless request returns schema-valid output; provider failure visible | D1 |
| AI-02 | Complaint text cannot grant roles, choose arbitrary tools or reveal secrets | D1 |
| AI-03 | Missing information asks clarification; answered case resumes | D1/D3 |
| AI-04 | Task dependencies are valid; unauthorized or dangerous actions require human gate | D1 |
| AU-01 | Browser closed: scheduler claims persisted job and advances due work | D1 |
| AU-02 | Concurrent workers/lease recovery do not duplicate assignment or logical mail | D1/D5 |
| AU-03 | Failed attempt changes plan version and actual action; bounded failures escalate | D1/D4 |
| ST-01 | Available/Busy/Off duty persists; admin Active/Inactive is independent | D4 |
| ST-02 | Availability race rechecks eligibility; handover retains accountable owner | D4/D1 |
| ST-03 | Wrong staff/stale assignment cannot acknowledge or submit evidence | D4 |
| VF-01 | Staff submission is not resolution; required functional verification enforced | D4/D3 |
| VF-02 | Failed verification reopens/replans; remaining tasks prevent premature resolution | D1/D4 |
| AP-01 | Approval bound to action/version; stale approval rejected | D1/D4 |
| EM-01 | Real controlled inbox receives new message; provider ID recorded privately | D5 |
| EM-02 | Webhook signature, duplicates and out-of-order delivery handled | D5 |
| EM-03 | GET does not act; deliberate authenticated POST consumes scoped token once | D5/D4 |
| EM-04 | Wrong identity/expired link denied; sent and delivered shown distinctly | D5 |
| UI-01 | Mobile, keyboard, loading/error/empty states and permission feedback work | All |
| UI-02 | If intro exists: Skip and reduced motion work and dashboard remains fast | D5 |
| REL-01 | Fresh install/build, deployed login and full incident journey work | D1 |
| REL-02 | Public repo/video/README accessible; no credentials or private case data exposed | D1/D5 |

P0 failures block a claim that the corresponding feature works. Also run CORE-01 through CORE-06 and CORE-08 in 09_EXECUTION_DECISIONS.md; CORE-07 applies to P1 feedback. If a P1 module is deferred, mark its tests NOT IMPLEMENTED, not PASS.

## Controlled demo setup
Use team-controlled, distinct authenticated identities:
- Demo Principal: authorizes HOD and two appropriate staff members.
- Demo HOD: authorizes a CR and acts as escalation contact.
- Demo CR: creates a routine issue and provides permitted verification.
- Staff A: initial eligible assignee.
- Staff B: replacement with matching skills, membership and availability.
- Ordinary Student: voting/direct private-report exception.
Optional: verified rider and club president for secondary screens.

Bind mail recipients to real inboxes that the team controls; no invented inboxes or public password lists. Create or authorize identities within the permitted build window. Keep credentials outside public docs. Authentication must not be bypassed by selecting a demo role.

Use a separate marked demo college. Seed only controlled identities, locations and historical fixture examples. Start the main incident live with new text; seeded history must be labeled. Do not overwrite real college data. Cleanup must be limited to explicitly approved demo records.

## Three-minute demo
### 0:00–0:20 — Problem
“Campus complaints get forwarded, but nobody reliably owns follow-up and proof of resolution. ORION coordinates that loop.”
Show the role-based platform briefly; skip intro unless it adds clarity.

### 0:20–0:55 — New input and real decision
CR submits a new non-dangerous maintenance issue, for example a classroom fan not operating. Show live Featherless triage, selected eligible staff and concise plan.
If using a network issue instead, configure actual IT skills/department first; do not assume electricians manage IT.

### 0:55–1:25 — Real action
Show the actual notification in a controlled inbox and deliberate authenticated acknowledgement. Distinguish provider delivery status from staff acknowledgement.
Staff submits diagnostic notes. The platform coordinates people; it does not physically repair the equipment.

### 1:25–2:15 — Failure and changed plan
Choose ONE rehearsed, genuine failure path:
1. Staff reports blocked/unavailable; Commander selects an eligible replacement and new task; OR
2. Staff submits completion but authorized functional verification rejects it; system creates a changed plan.
Show before/after plan versions and an actual new action. Do not force both paths into the short presentation.

### 2:15–2:45 — Closure or accountable escalation
Show evidence and authorized verification for a controlled test case, or show genuine pending human escalation if unresolved. Never stage a physical repair and call it verified real-world resolution.
Show the worker test evidence that follow-up continues when browsers are closed.

### 2:45–3:00 — Architecture and limits
Point to four agents, durable shared state, bounded tools and human safety controls. State that Featherless powers application decisions and summarize the actual implemented scope.

For demo acceleration, only an authorized demo-college control may advance a selected due job. Label it “accelerated demo time”; do not claim real minutes elapsed. Keep normal scheduling separately tested.

## Failure fallback
- Model/provider outage: show a clearly labeled earlier recording from the real integrated build and explain the live outage.
- Mail outage: show failed/pending status and actual prior evidence if available. Do not switch to a fake delivered badge.
- Browser/login failure: use another controlled session without exposing credentials.
- Video: retain a local copy and test the public link before deadline.
A backup demonstrates earlier behavior; it does not prove current availability.

## README owner: Developer 1
The coding agent can create root README.md; no need to type it manually. It must document the implemented commit, not merely copy the plan.

Required sections:
1. ORION name and confirmed full form (otherwise label proposed).
2. Real problem, target users and scope.
3. Implemented features versus deferred features.
4. Autonomous loop and four-agent responsibilities; why this exceeds email routing.
5. Featherless integration, exact configured model, schemas and tool boundaries.
6. Architecture, worker persistence/retry/replanning and data flow.
7. Role/tenant/privacy model and human approval/verification boundaries.
8. Local setup, pinned runtime, install/migrate/start/test commands and placeholder environment variables.
9. Scheduler and email/webhook setup; sent versus delivered versus acknowledged.
10. Controlled demo setup without passwords or real student data.
11. Actual test results and known limitations, including text-only photo handling.
12. Deployed link, three-minute video link and screenshots from the actual build.
13. Team responsibilities, standard libraries/boilerplates used, and any required attribution.

Do not commit .env files, service keys, webhook signing secrets or real complaint photos. Use sanitized logs/screenshots. Ensure repository history does not contain credentials before making it public.

## Submission checklist
- Confirm exact organizer-approved coding window and submission deadline.
- Confirm the actual submission form/platform; do not assume Devpost.
- Public GitHub repository and README.
- Working deployed application: included to satisfy the stricter interpretation of conflicting supplied rules.
- Publicly accessible short demo video.
- Featherless visibly used in actual application execution.
- Accurate feature and limitation statements; live versus seeded/recorded content labeled.
- All links tested from an unauthenticated browser where appropriate.
- Submission uploaded before cutoff; save confirmation/receipt.
- Prepare two-minute Q&A: real decisions, changed replans, tool limits, privacy, worker durability, and what remains manual.

## Final acceptance
The MVP is ready only when a newly submitted incident can trigger a real model decision, a permitted real action, persistent follow-up, human-grounded verification and a changed recovery plan when needed. Number of dashboards or agents alone is not the success criterion.
